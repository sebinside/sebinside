public class WhatAmIDoingHere {
    public static void main(String[] args) {
        System.out.println("Hello JPlag!");
    }
}
