public interface TokenConstants {
  final static int FILE_END = 0;
	/**
	 * Used to optionally separate methods from each other with an always marked
	 * token
	 */
  final static int SEPARATOR_TOKEN = 1;
}
